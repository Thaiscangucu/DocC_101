//
//  ContentView.swift
//  docC_101
//
//  Created by Thais Cangucu on 29/01/26.
//

import SwiftUI

struct ContentView: View {
    @State var a = 0
    @State var b = 0
    @State var result = 0
    @State var name = ""
    @State var age = ""
    @State var greeting = ""

    
    var body: some View {
        VStack {
            TextField("Nome", text: $name)
                .textFieldStyle(.roundedBorder)
                .padding()
            TextField("Idade", text: $age)
                .textFieldStyle(.roundedBorder)
                .padding()
            Button{
                greeting = greet(person: Person(name: name, age: age))
            }
            label:{
                Text("Greet")
                    .padding(10)
                    .foregroundStyle(.white)
                    .background{
                        RoundedRectangle(cornerRadius: 15)
                    }
            }
            .padding()
            Text(greeting)
                .padding()
            TextField("A: ", value: $a, format: .number)
                .textFieldStyle(.roundedBorder)
                .keyboardType(.numberPad)
                .padding()
            TextField("B: ", value: $b, format: .number)
                .textFieldStyle(.roundedBorder)
                .keyboardType(.numberPad)
                .padding()
                .onSubmit {
                    result = multiply(a: a, b: b)
                }
            Text("Resultado de \(a) x \(b) = \(result)")
        }
        .padding()
    }
    
    /// Adds two Int numbers
    ///
    /// - Parameters:
    ///   - a: Int number
    ///   - b: Int number
    /// - Returns: Int number, result of a + b.
    ///
    /// This is a function that takes two number and multiplies them and retrun the result of that.
    ///
    /// ```swift
    /// a + b
    /// ```
    ///
    ///>Important:
    ///Important information about the function
    ///
    ///>Warning:
    ///Warning information about the function
    ///
    ///>Tip:
    ///Tip about the function
    ///
    ///>Experiment:
    ///Experiment
    func add(_ a: Int, _ b: Int) -> Int {
        a + b
    }
    
    /// Multiplies two numbers
    ///
    /// - Parameters:
    ///   - a: Int number
    ///   - b: Int number
    /// - Returns: Int number, result of a * b.
    ///
    /// This is a function that takes two number and multiplies them and retrun the result of that.
    ///
    /// ```swift
    /// a * b
    /// ```
    ///
    ///>Important:
    ///Important information about the function
    ///
    ///>Warning:
    ///Warning information about the function
    ///
    ///>Tip:
    ///Tip about the function
    ///
    ///>Experiment:
    ///Experiment
    func multiply(a: Int, b: Int) -> Int {
        a * b
    }
    
    
    /// Takes a Person object and prints person's name and age
    ///
    /// Here is where the discussion about the function is
    ///
    /// - Parameter person: ``Person``
    ///
    /// ```swift
    /// print("Hello, \(person.name)!")
    /// ```
    ///
    ///>Important:
    ///Important information about the function
    ///
    ///>Warning:
    ///Warning information about the function
    ///
    ///>Tip:
    ///Tip about the function
    ///
    ///>Experiment:
    ///Experiment
    ///
    func greet(person: Person) -> String {
        return ("Hello, \(person.name)! You are \(person.age) old!")
    }
}

struct Person{
    var name: String
    var age: String
}

#Preview {
    ContentView()
}
