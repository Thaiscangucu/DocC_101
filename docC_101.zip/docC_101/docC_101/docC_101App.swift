//
//  docC_101App.swift
//  docC_101
//
//  Created by Thais Cangucu on 29/01/26.
//

import SwiftUI

@main
struct docC_101App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
