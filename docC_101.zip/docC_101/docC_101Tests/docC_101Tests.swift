//
//  docC_101Tests.swift
//  docC_101Tests
//
//  Created by Thais Cangucu on 29/01/26.
//

import Testing
@testable import docC_101

struct docC_101Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
